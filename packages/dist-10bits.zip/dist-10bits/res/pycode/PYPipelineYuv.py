
import PYRender
import TGL

class YuvPipeline(PYRender.IPipeline):
	def __init__(self):
		PYRender.IPipeline.__init__(self)
		with open("../res/glsl_shader/paint.tranfrom.vert") as shader_file:
			self.vertex_shader = ''.join(shader_file.readlines())
		with open("../res/glsl_shader/paint.yuv.frag") as shader_file:
			self.rgb_fragment_shader = ''.join(shader_file.readlines())
		self.pipeline_name = 'rgba'
		self.shader = PYRender.Shader()
		self.shader.set_shader(TGL.GL_VERTEX_SHADER, self.vertex_shader, len(self.vertex_shader))
		self.shader.set_shader(TGL.GL_FRAGMENT_SHADER, self.rgb_fragment_shader, len(self.rgb_fragment_shader))
		self.shader.link()
	def name(self):
		return self.pipeline_name
	def load(self, loader, source_data, mem_image):
		loader.load(source_data.tex_buffer[0], mem_image.data[0], mem_image.line_size[0]*mem_image.height)
		return 0
	def upload(self, render_ctx, mem_image, device_image):
		device_image.tex_info.width = mem_image.width
		device_image.tex_info.height = mem_image.height
		device_image.tex_info.line_size[0] = mem_image.line_size[0]
		device_image.tex_info.pixel_format = mem_image.pixel_format
		pixel_type = TGL.GL_RGBA
		if (PYRender.pixel_format_rgb24 == device_image.tex_info.pixel_format or PYRender.pixel_format_bgr24 == device_image.tex_info.pixel_format):
			pixel_type = TGL.GL_RGB
		elif (PYRender.pixel_format_gray8 == device_image.tex_info.pixel_format):
			pixel_type = TGL.GL_RED
		TGL.glBindTexture(TGL.GL_TEXTURE_2D, device_image.gl_tex_src_array[0])
		TGL.glTexParameteri(TGL.GL_TEXTURE_2D, TGL.GL_TEXTURE_MAG_FILTER, TGL.GL_LINEAR)
		TGL.glTexParameteri(TGL.GL_TEXTURE_2D, TGL.GL_TEXTURE_MIN_FILTER, TGL.GL_LINEAR)
		TGL.glTexParameteri(TGL.GL_TEXTURE_2D, TGL.GL_TEXTURE_WRAP_S, TGL.GL_CLAMP_TO_EDGE)
		TGL.glTexParameteri(TGL.GL_TEXTURE_2D, TGL.GL_TEXTURE_WRAP_T, TGL.GL_CLAMP_TO_EDGE)
		TGL.glTexImage2D(TGL.GL_TEXTURE_2D, 0, TGL.GL_RGBA, mem_image.width, mem_image.height, 0, pixel_type, TGL.GL_UNSIGNED_BYTE, mem_image.data[0])
		return 0
	def render(self, render_ctx, tex, render_param):
		TGL.glBindTexture(TGL.GL_TEXTURE_2D, tex.gl_tex_src_array[0])
		TGL.glBindVertexArray(render_param.current_vao_buffer.id)
		self.shader.bind()
		self.shader.bind_attrib_location(0, "attr_vertex")
		self.shader.bind_attrib_location(1, "attr_texcoord")
		self.shader.set_uniform_matrix_4x4("unifm_mvp_mat", 1, 0, render_ctx.mvp_mat44)
		self.shader.set_uniform1i("tex2D_v", 0, -1)
		if PYRender.pixel_format_bgr24 == tex.tex_info.pixel_format or PYRender.pixel_format_bgra32 == tex.tex_info.pixel_format:
			self.shader.set_uniform1f("b_is_rgb", 0.0, -1)
		else:
			self.shader.set_uniform1f("b_is_rgb", 1.0, -1)

		if render_param.is_using_flip:
			flip_x = (1.0 if render_param.is_flip_horizontal else 0.0)
			flip_y = (1.0 if render_param.is_flip_vertical else 0.0)
			self.shader.set_uniform2f("b_is_flip", flip_x, flip_y, -1)
		else:
			self.shader.set_uniform2f("b_is_flip", 0.0, 0.0, -1)

		TGL.glDrawArrays(TGL.GL_TRIANGLE_FAN, 0, 4)
		TGL.glBindVertexArray(0)
		TGL.glBindTexture(TGL.GL_TEXTURE_2D, 0)
		self.shader.unbind()
		return 0;

def get_pipeline_array():
	return ['PYPipelineYuv']
