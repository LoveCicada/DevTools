

vertext_shader = """

/*precision lowp float;*/
/*precision mediump float;*/
/*precision highp float;*/

/*uniform mat4 unifm_project_mat;*/
/*uniform mat4 unifm_model_view_mat;*/
uniform mat4 unifm_mvp_mat;
attribute vec4 attr_vertex;
attribute vec2 attr_texcoord;
varying vec2 v_Texcoord;
void main(void)
{
    /*gl_Position = ftransform()*/;
    /*gl_Position = vec4(attr_vertex.xy, 1.0, 1.0)*/;
    /*gl_Position = unifm_project_mat*unifm_model_view_mat*vec4(attr_vertex.xy, 1.0, 1.0);*/
    /*gl_Position = unifm_mvp_mat*vec4(attr_vertex.xy, 1.0, 1.0);*/
    gl_Position = unifm_mvp_mat*attr_vertex;
    v_Texcoord  = attr_texcoord;
    /*v_Texcoord  = vec2(gl_Vertex.s, 1.0-gl_Vertex.t);*/
}

"""
