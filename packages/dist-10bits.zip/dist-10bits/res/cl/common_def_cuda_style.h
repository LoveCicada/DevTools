
#ifndef threadIdx_x

#define threadIdx_x get_local_id(0)
#define threadIdx_y get_local_id(1)
#define threadIdx_z get_local_id(2)

#define threadIdx_gx get_global_id(0)
#define threadIdx_gy get_global_id(1)
#define threadIdx_gz get_global_id(2)

#define blockIdx_x  get_group_id(0)
#define blockIdx_y  get_group_id(1)
#define blockIdx_z  get_group_id(2)

#define blockDim_x  get_local_size(0)
#define blockDim_y  get_local_size(1)
#define blockDim_z  get_local_size(2)

#endif
