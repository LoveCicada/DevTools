
guid__={}
test_abc_ = XXGUID()
aaa = 1000

function add(x, y)
	print(x+y)
	testFunc()
end

function foobar()
    print( "foobar!" )
end

function foobar_guid(x, y, cpp)
	-- test_abc_ = XXGUID()
	print("-----------------------------------")
	d = XXGUID(aaa)
	-- print(test_abc_)
	-- print(aaa)
	-- -- x:print()
	-- -- print(cpp:f(100))
	-- -- a.guid = aaa
	-- d = XXGUID(aaa)
	-- -- a = d:equal(test_abc_)
	-- a = d:equal(y)
	-- -- a = d == 1000
	-- -- e = op_test1()
	-- if (a) then
	--  	print( "eq" )
	-- else
	--  	print( "not eq" )
	-- end

	-- if (a) then
	--  	print( "abc_ eq" )
	-- else
	--  	print( "abc_ not eq" )
	-- end
end
