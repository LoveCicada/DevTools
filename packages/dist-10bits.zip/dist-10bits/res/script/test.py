
#import TEST_PY

a = 0
b = 0

def test():
	print ("a"+"b"+"c")

def retOut(a=0.0, b=1.2):
	print(dir(a))
	print(a)
	print(b)
	return (111.0, 2.0, 3.0, 4.0)

def Test_XXGUID(a, b):
	print("Test_XXGUID")
	teq = a == b
	if (teq):
		print("eq")
	else:
		print("not eq")
